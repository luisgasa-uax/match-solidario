<footer>
    <div class="organiza">
        <p>Organiza</p>
        <a href="https://www.uax.com/fps"><img src="uax-fp.png" alt="Logo UAX FP"></a>
    </div>
    <div class="colaboran">
        <div class="colaborador"><a href="#"><img src="fundacion-uax.png" alt="Logo Fundación UAX"></a></div>
        <div class="colaborador"><a href="#"><img src="sodexo.png" alt="Logo Sodexo"></a></div>
        <div class="colaborador"><a href="#"><img src="red-innicia.png" alt="Logo Red Innicia"></a></div>
        <div class="colaborador"><a href="#"><img src="uax.png" alt="Logo UAX"></a></div>
    </div>
</footer>
