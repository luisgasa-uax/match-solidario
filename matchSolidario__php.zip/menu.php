<nav>
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="haz-match.php">Match</a></li>
        <li><a href="quienes-somos.php">Quienes somos</a></li>
        <li><a href="https://innicia.org/">Red Innicia</a></li>
    </ul>
</nav>
